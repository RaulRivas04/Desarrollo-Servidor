<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registro Exitoso</title>
</head>
<body>
    <?php include 'layout/header.php'; ?>
    <h1>Usuario registrado exitosamente</h1>
    <p>Ahora puede <a href="<?= BASE_URL ?>/login">iniciar sesión</a>.</p>
    <?php include 'layout/footer.php'; ?>
</body>
</html>