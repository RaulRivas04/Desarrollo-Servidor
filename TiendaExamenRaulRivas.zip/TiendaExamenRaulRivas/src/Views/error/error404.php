<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $titulo ?></title>
</head>
<body>
    <h1>404 - Página no encontrada</h1>
    <p>Tal vez quieras volver al inicio</p>
    <a href="<?= BASE_URL ?>">Ir al inicio</a>
</body>
</html>