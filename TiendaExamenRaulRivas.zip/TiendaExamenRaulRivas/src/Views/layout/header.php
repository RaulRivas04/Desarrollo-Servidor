<header>
    <h1 style="color: white;">CorreosExpress Mensajeria</h1>
    <nav>
        <ul>
            <li><a href="<?= BASE_URL ?>">Inicio</a></li>
            <li><a href="<?= BASE_URL ?>/login">Iniciar Sesion</a></li>
            <li><a href="<?= BASE_URL ?>/registro">Registrarse</a></li>
        </ul>
    </nav>
</header>