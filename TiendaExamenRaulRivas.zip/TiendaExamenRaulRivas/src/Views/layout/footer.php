<footer>
    <p>CorreosMenssenger Derechos reservados</p>
</footer>