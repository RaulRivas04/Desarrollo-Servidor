<?php
// Incluye el archivo de inicialización del proyecto
require_once __DIR__ . '/../src/init.php';
?>
