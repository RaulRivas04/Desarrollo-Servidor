<h3>Listado de Categorías</h3>
<ul>
    <?php if (empty($categorias)): ?>
        <li>No hay categorías disponibles.</li>
    <?php else: ?>
        <?php foreach ($categorias as $categoria): ?>
            <li><?= htmlspecialchars($categoria->getNombre()) ?></li>
        <?php endforeach; ?>
    <?php endif; ?>
</ul>