<?php
// Formulario de registro de usuarios
// Actualizado para manejar datos con validación
?>

<h3>Registro de Usuario</h3>
<form action="<?=BASE_URL?>/user/register" method="POST">
    <label for="name">Nombre</label>
    <input type="text" name="data[nombre]" id="name" required>

    <label for="lastname">Apellido</label>
    <input type="text" name="data[lastname]" id="lastname" required>

    <label for="email">Correo electrónico</label>
    <input type="email" name="data[email]" id="email" required>

    <label for="password">Contraseña</label>
    <input type="password" name="data[password]" id="password" required>

    <button type="submit">Registrarse</button>
</form>

<hr>

<h3>Añadir Producto</h3>
<form action="<?=BASE_URL?>/product/add" method="POST" enctype="multipart/form-data">
    <label for="product_name">Nombre del producto</label>
    <input type="text" name="product[name]" id="product_name" required>

    <label for="product_description">Descripción</label>
    <textarea name="product[description]" id="product_description" required></textarea>

    <label for="product_price">Precio</label>
    <input type="number" name="product[price]" id="product_price" step="0.01" required>

    <label for="product_image">Imagen</label>
    <input type="file" name="product[image]" id="product_image" accept="image/*">

    <button type="submit">Añadir Producto</button>
</form>
