<h3>Confirmar Pago</h3>
<div class="cart-container">
    <table class="cart-table">
        <thead>
            <tr>
                <th>Imagen</th>
                <th>Producto</th>
                <th>Precio</th>
                <th>Cantidad</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $total = 0;
            foreach ($productos as $producto): 
                $subtotal = $producto['precio'] * $producto['cantidad'];
                $total += $subtotal;
            ?>
                <tr>
                    <td><img src="<?= BASE_URL ?>public/img/<?= htmlspecialchars($producto['imagen']) ?>" alt="<?= htmlspecialchars($producto['nombre']) ?>" class="cart-product-image"></td>
                    <td><?= htmlspecialchars($producto['nombre']) ?></td>
                    <td>€<?= htmlspecialchars($producto['precio']) ?></td>
                    <td><?= htmlspecialchars($producto['cantidad']) ?></td>
                    <td>€<?= htmlspecialchars($subtotal) ?></td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td colspan="4" class="total-label"><strong>Total:</strong></td>
                <td class="total-value"><strong>€<?= htmlspecialchars($total) ?></strong></td>
            </tr>
        </tbody>
    </table>
</div>

<div class="payment-method">
    <p><strong>Método de Pago Seleccionado:</strong> <?= htmlspecialchars($metodoPago) ?></p>
</div>

<form action="<?= BASE_URL ?>carrito/pagar" method="POST" class="cart-form">
    <input type="hidden" name="metodo_pago" value="<?= htmlspecialchars($metodoPago) ?>">
    <button type="submit" class="cart-button">Confirmar y Pagar</button>
</form>