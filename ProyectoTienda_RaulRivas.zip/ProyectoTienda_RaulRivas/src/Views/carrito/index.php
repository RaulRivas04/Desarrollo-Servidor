<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compras</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>public/css/styles.css">
</head>
<body>
    <h3>Carrito de Compras</h3>
    <div class="cart-container">
        <?php if (empty($carrito)): ?>
            <p>No hay productos en el carrito.</p>
        <?php else: ?>
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Precio</th>
                        <th>Cantidad</th>
                        <th>Total</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($carrito as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item->getNombre()) ?></td>
                            <td>€<?= htmlspecialchars($item->getPrecio()) ?></td>
                            <td><?= htmlspecialchars($item->getCantidad()) ?></td>
                            <td>€<?= htmlspecialchars($item->getTotal()) ?></td>
                            <td>
                                <form action="<?= BASE_URL ?>carrito/eliminar" method="POST" class="remove-from-cart-form">
                                    <input type="hidden" name="producto_id" value="<?= htmlspecialchars($item->getId()) ?>">
                                    <button type="submit" class="remove-from-cart-button">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="total-label">
                Total: €<?= htmlspecialchars($total) ?>
            </div>
            <div class="cart-form">
                <button class="cart-button">Proceder al Pago</button>
            </div>
        <?php endif; ?>
    </div>

    <!-- Incluir el archivo JavaScript -->
    <script src="<?= BASE_URL ?>public/js/scripts.js"></script>
</body>
</html>