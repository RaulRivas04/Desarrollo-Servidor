<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Formulario de Pago</title>
</head>
<body>
    <form action="<?= BASE_URL ?>pagar" method="POST">
        <!-- Campos del formulario -->
        <button type="submit">Pagar</button>
    </form>
</body>
</html>