<?php foreach ($productos as $producto): ?>
    <div class="producto">
        <h2><?php echo $producto->getNombre(); ?></h2>
        <p>Precio: <?php echo $producto->getPrecio(); ?> €</p>
        <p>Cantidad: <?php echo $producto->getCantidad(); ?></p>
        <div class="acciones">
            <form action="eliminar_producto.php" method="post">
                <input type="hidden" name="id" value="<?php echo $producto->getId(); ?>">
                <button type="submit">Eliminar</button>
            </form>
            <form action="actualizar_cantidad.php" method="post">
                <input type="hidden" name="id" value="<?php echo $producto->getId(); ?>">
                <button type="submit" name="accion" value="incrementar">+</button>
                <button type="submit" name="accion" value="decrementar">-</button>
            </form>
        </div>
    </div>
<?php endforeach; ?>