</div> <!-- Cerrar el div container -->
    <footer>
        <p>&copy; <?= date('Y') ?> Mi Tienda. Todos los derechos reservados.</p>
    </footer>
</body>
</html>