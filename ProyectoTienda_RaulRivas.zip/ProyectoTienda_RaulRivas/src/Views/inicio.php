<?php
// Incluye el encabezado
require_once __DIR__ . '/layout/header.php';
?>

<!-- Contenido principal -->
<div class="container">
    <h1>Bienvenido a miTienda</h1>
    <p>Esta es tu página de inicio.</p>
</div>

<?php
// Incluye el pie de página
require_once __DIR__ . '/layout/footer.php';
?>
