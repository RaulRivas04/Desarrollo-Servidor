<hr>
<h3><?php echo $titulo; ?></h3>

<p>Tal vez quieras volver a Inicio</p>
<a href="<?= BASE_URL ?>public/">Volver a Inicio</a>
