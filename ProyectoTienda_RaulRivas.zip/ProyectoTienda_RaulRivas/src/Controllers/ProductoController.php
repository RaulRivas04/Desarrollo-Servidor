<?php

namespace Controllers;

use Lib\Pages;
use Services\ProductoService;
use Lib\Validator;
use Lib\ValidationException;
use Utils;
use Controllers\PagoController; // Asegúrate de importar PagoController si es necesario

class ProductoController
{
    private Pages $pages;
    private ProductoService $productoService;

    public function __construct()
    {
        $this->pages = new Pages();
        $this->productoService = new ProductoService();
    }

    public function create()
    {
        if (!Utils::isAdmin()) {
            header('Location: ' . BASE_URL);
            exit;
        }

        $data = $_POST['data'] ?? [];

        $rules = [
            'nombre' => '/^[a-zA-Z\s]+$/',
            'precio' => '/^\d+(\.\d{1,2})?$/'
        ];

        try {
            Validator::validate($data, $rules);
            $this->productoService->createProducto($data['nombre'], (float)$data['precio']);
            $_SESSION['success_message'] = 'Producto creado exitosamente.';
            header('Location: ' . BASE_URL . 'producto/index');
            exit;
        } catch (ValidationException $e) {
            $_SESSION['error_message'] = implode('<br>', $e->getErrors());
            header('Location: ' . BASE_URL . 'producto/create');
            exit;
        }
    }

    public function index()
    {
        $productos = $this->productoService->getAllProductos();
        $this->pages->render('producto/index', ['productos' => $productos]);
    }

    public function verFormulario()
    {
        $this->pages->render('producto/create');
    }

    public function guardarProducto()
    {
        $this->create();
    }

    public function verProductos()
    {
        $this->index();
    }
}
?>