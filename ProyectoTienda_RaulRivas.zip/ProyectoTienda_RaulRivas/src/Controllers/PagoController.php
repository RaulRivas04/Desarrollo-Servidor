<?php

namespace Controllers;

class PagoController {
    public function procesarPago() {
        // Lógica para procesar el pago
        echo "Pago realizado con éxito.";
    }
}
?>