<?php

namespace Controllers;

use Lib\Pages;
use Services\CategoriaService;
use Lib\Validator;
use Lib\ValidationException;
use Utils;
use Controllers\PagoController; // Asegúrate de importar PagoController si es necesario

class CategoriaController
{
    private Pages $pages;
    private CategoriaService $categoriaService;

    public function __construct()
    {
        $this->pages = new Pages();
        $this->categoriaService = new CategoriaService();
    }

    public function create()
    {
        if (!Utils::isAdmin()) {
            header('Location: ' . BASE_URL);
            exit;
        }

        $data = $_POST['data'] ?? [];

        $rules = [
            'nombre' => '/^[a-zA-Z\s]+$/'
        ];

        try {
            Validator::validate($data, $rules);
            $this->categoriaService->createCategoria($data['nombre']);
            $_SESSION['success_message'] = 'Categoría creada exitosamente.';
            header('Location: ' . BASE_URL . 'categoria/index');
            exit;
        } catch (ValidationException $e) {
            $_SESSION['error_message'] = implode('<br>', $e->getErrors());
            header('Location: ' . BASE_URL . 'categoria/create');
            exit;
        }
    }

    public function index()
    {
        $categorias = $this->categoriaService->getAllCategorias();
        $this->pages->render('categoria/index', ['categorias' => $categorias]);
    }

    public function verFormulario()
    {
        $this->pages->render('categoria/create');
    }

    public function guardarCategoria()
    {
        $this->create();
    }

    public function verCategorias()
    {
        $this->index();
    }
}