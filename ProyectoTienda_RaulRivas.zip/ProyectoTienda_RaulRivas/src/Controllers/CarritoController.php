<?php
// filepath: /c:/xampp/htdocs/ProyectoTienda_RaulRivas/src/Controllers/CarritoController.php
namespace Controllers;

use Lib\Pages;
use Services\CarritoService;
use Utils;

class CarritoController
{
    private Pages $pages;
    private CarritoService $carritoService;

    public function __construct()
    {
        $this->pages = new Pages();
        $this->carritoService = new CarritoService();
    }

    public function verCarrito()
    {
        if (!Utils::isLoggedIn()) {
            header('Location: ' . BASE_URL . 'login');
            exit;
        }

        $userId = $_SESSION['user']['id'];
        $productos = $this->carritoService->obtenerProductosEnCarrito($userId);

        $this->pages->render('carrito/verCarrito', ['productos' => $productos]);
    }

    public function confirmarPago()
    {
        if (!Utils::isLoggedIn()) {
            header('Location: ' . BASE_URL . 'login');
            exit;
        }

        $metodoPago = $_POST['metodo_pago'];
        $userId = $_SESSION['user']['id'];
        $productos = $this->carritoService->obtenerProductosEnCarrito($userId);

        $this->pages->render('carrito/confirmarPago', ['productos' => $productos, 'metodoPago' => $metodoPago]);
    }

    public function pagar()
    {
        if (!Utils::isLoggedIn()) {
            header('Location: ' . BASE_URL . 'login');
            exit;
        }

        $userId = $_SESSION['user']['id'];
        $metodoPago = $_POST['metodo_pago'];
        $productos = $this->carritoService->obtenerProductosEnCarrito($userId);

        if ($this->carritoService->crearPedido($userId, $metodoPago, $productos)) {
            $this->carritoService->vaciarCarrito($userId);
            $_SESSION['success_message'] = 'Compra realizada exitosamente.';
        } else {
            $_SESSION['error_message'] = 'Hubo un problema al procesar su compra. Por favor, inténtelo de nuevo.';
        }

        header('Location: ' . BASE_URL . 'carrito/verCarrito');
        exit;
    }

    public function agregarProducto()
    {
        if (!Utils::isLoggedIn()) {
            header('Location: ' . BASE_URL . 'login');
            exit;
        }

        $userId = $_SESSION['user']['id'];
        $productoId = $_POST['producto_id'];
        $cantidad = $_POST['cantidad'];

        $this->carritoService->agregarProductoAlCarrito($userId, $productoId, $cantidad);

        $_SESSION['success_message'] = 'Producto añadido al carrito.';
        header('Location: ' . BASE_URL . 'producto/index');
        exit;
    }

    public function eliminar()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $producto_id = $_POST['producto_id'];
            $carrito = new Carrito();
            $carrito->eliminarProducto($producto_id);
            header('Location: ' . BASE_URL . 'carrito');
            exit();
        }
    }

    public function vaciar()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $userId = $_SESSION['user']['id'];
            $this->carritoService->vaciarCarrito($userId);
            echo json_encode(['success' => true]);
            exit();
        }
    }
}