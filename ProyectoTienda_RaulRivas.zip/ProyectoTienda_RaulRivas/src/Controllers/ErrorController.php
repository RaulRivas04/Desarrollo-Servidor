<?php

namespace Src\Controllers;

use Lib\Pages;
use Controllers\PagoController; // Asegúrate de importar PagoController si es necesario

class ErrorController
{
    public static function error404(string $message = 'Página no encontrada'): void
    {
        echo "<h1>Error 404</h1>";
        echo "<p>$message</p>";
    }
}
?>