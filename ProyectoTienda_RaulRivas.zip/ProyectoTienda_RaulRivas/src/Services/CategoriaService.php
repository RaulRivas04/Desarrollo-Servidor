<?php

namespace Services;

use Models\Categoria;
use Repositories\CategoriaRepository;

class CategoriaService
{
    private CategoriaRepository $categoriaRepository;

    public function __construct()
    {
        $this->categoriaRepository = new CategoriaRepository();
    }

    public function createCategoria(string $nombre): void
    {
        $categoria = new Categoria($nombre);
        $this->categoriaRepository.save($categoria);
    }

    public function getAllCategorias(): array
    {
        return $this->categoriaRepository->findAll();
    }
}