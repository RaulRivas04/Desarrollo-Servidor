<?php

namespace Services;

use Models\Pedido;
use Repositories\CarritoRepository;

class CarritoService
{
    private CarritoRepository $carritoRepository;
    private Pedido $pedido;

    public function __construct()
    {
        $this->carritoRepository = new CarritoRepository();
        $this->pedido = new Pedido();
    }

    public function obtenerProductosEnCarrito(int $userId): array
    {
        return $this->carritoRepository->getProductosEnCarrito($userId);
    }

    public function agregarProductoAlCarrito(int $userId, int $productoId, int $cantidad): void
    {
        $this->carritoRepository->agregarProductoAlCarrito($userId, $productoId, $cantidad);
    }

    public function vaciarCarrito(int $userId): void
    {
        $this->carritoRepository->vaciarCarrito($userId);
    }

    public function crearPedido(int $userId, string $metodoPago, array $productos): bool
    {
        // Implementación del método crearPedido
    }
}