<?php

namespace Services;

use Models\Producto;
use Repositories\ProductoRepository;

class ProductoService
{
    private ProductoRepository $productoRepository;

    public function __construct()
    {
        $this->productoRepository = new ProductoRepository();
    }

    public function getAllProductos(): array
    {
        return $this->productoRepository->findAll();
    }
}