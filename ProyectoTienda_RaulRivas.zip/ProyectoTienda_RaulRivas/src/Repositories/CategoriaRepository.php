<?php

namespace Repositories;

use Models\Categoria;
use PDO;

class CategoriaRepository
{
    private PDO $db;

    public function __construct()
    {
        $this->db = new PDO('mysql:host=localhost;dbname=tienda', 'root', '');
    }

    public function save(Categoria $categoria): void
    {
        $stmt = $this->db->prepare('INSERT INTO categorias (nombre) VALUES (:nombre)');
        $stmt->bindParam(':nombre', $categoria->getNombre(), PDO::PARAM_STR);
        $stmt->execute();
    }

    public function findAll(): array
    {
        $stmt = $this->db->query('SELECT * FROM categorias');
        $categorias = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return array_map(fn($data) => new Categoria($data['nombre']), $categorias);
    }
}