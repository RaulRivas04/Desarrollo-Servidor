<?php

namespace Repositories;

use Models\Producto;
use PDO;

class ProductoRepository
{
    private PDO $db;

    public function __construct()
    {
        $this->db = new PDO('mysql:host=localhost;dbname=tienda', 'root', '');
    }

    public function findAll(): array
    {
        $stmt = $this->db->query('SELECT * FROM productos');
        $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return array_map(fn($data) => new Producto($data['id'], $data['nombre'], $data['precio'], $data['imagen']), $productos);
    }

    public function findByCategoria(int $categoriaId): array
    {
        $stmt = $this->db->prepare('SELECT * FROM productos WHERE categoria_id = :categoria_id');
        $stmt->bindParam(':categoria_id', $categoriaId, PDO::PARAM_INT);
        $stmt->execute();
        $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return array_map(fn($data) => new Producto($data['id'], $data['nombre'], $data['precio'], $data['imagen']), $productos);
    }
}