<?php

namespace Models;

class Producto
{
    private int $id;
    private string $nombre;
    private float $precio;
    private string $imagen;

    public function __construct(int $id, string $nombre, float $precio, string $imagen)
    {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->precio = $precio;
        $this->imagen = $imagen;
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getNombre(): string
    {
        return $this->nombre;
    }

    public function getPrecio(): float
    {
        return $this->precio;
    }

    public function getImagen(): string
    {
        return $this->imagen;
    }
}