<?php

namespace Models;

use PDO;

class Pedido
{
    private PDO $db;

    public function __construct()
    {
        $this->db = new PDO('mysql:host=localhost;dbname=tienda', 'root', '');
    }

    public function crearPedido(int $userId, string $metodoPago, array $productos): bool
    {
        $this->db->beginTransaction();

        try {
            $stmt = $this->db->prepare('INSERT INTO pedidos (usuario_id, metodo_pago, fecha) VALUES (:usuario_id, :metodo_pago, NOW())');
            $stmt->bindParam(':usuario_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':metodo_pago', $metodoPago, PDO::PARAM_STR);
            $stmt->execute();

            $pedidoId = $this->db->lastInsertId();

            foreach ($productos as $producto) {
                $stmt = $this->db->prepare('INSERT INTO pedidos_productos (pedido_id, producto_id, cantidad, precio) VALUES (:pedido_id, :producto_id, :cantidad, :precio)');
                $stmt->bindParam(':pedido_id', $pedidoId, PDO::PARAM_INT);
                $stmt->bindParam(':producto_id', $producto['id'], PDO::PARAM_INT);
                $stmt->bindParam(':cantidad', $producto['cantidad'], PDO::PARAM_INT);
                $stmt->bindParam(':precio', $producto['precio'], PDO::PARAM_STR);
                $stmt->execute();
            }

            $this->db->commit();
            return true;
        } catch (\Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }
}