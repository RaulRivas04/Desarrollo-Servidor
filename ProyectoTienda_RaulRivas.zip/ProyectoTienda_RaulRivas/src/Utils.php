<?php

class Utils
{
    public static function isAdmin(): bool
    {
        return isset($_SESSION['user']) && $_SESSION['user']['rol'] === 'admin';
    }

    public static function isLoggedIn(): bool
    {
        return isset($_SESSION['user']);
    }
}