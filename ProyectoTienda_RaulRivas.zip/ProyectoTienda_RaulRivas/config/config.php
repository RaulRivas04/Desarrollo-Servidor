<?php 
// URL base del proyecto
define("BASE_URL", "http://localhost/ProyectoTienda_RaulRivas/");
?>
